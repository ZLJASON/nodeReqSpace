/*===========================
Swiper
===========================*/
window.Swiper = function (container, params) {
    if (!(this instanceof Swiper)) return new Swiper(container, params);