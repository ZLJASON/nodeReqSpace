/**
 * Created by lfjt on 2015/9/1.
 */
require.config({
    paths: {
        jquery: '../lib/jquery-2.1.3',
        common: '../common',
        service: '../dataSource'
    }
});

require(["jquery","common",'service'], function($,common,service){
    //alert($("html").html())

});