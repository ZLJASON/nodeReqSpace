function getNews(opt, callBack) {
    soapGetData({
        dataMethod: "xml",
        url: 'http://mtest.xudc.com:8080/house/ws/articleservice?wsdl',
        methodName: 'getArticleList',
        data: opt,
        namespaceURL: 'http://mtest.xudc.com:8080/house',
        beforeSend: function () {
            showMsg({
                show: true,
                msg: '正在加载...'
            })
        },
        success: function (data) {
            // 关闭消息框
            showMsg({
                show: false
            });
            var _response = data.Body.getArticleListResponse.result;
            callBack && callBack(_response);
        },
        error: function (err) {
            // 关闭消息框
            showMsg({
                show: false
            });
            // 开启提示消息
            showMsg({
                show: true,
                msg: err || '',
                timeOutClose: true
            });
        }
    });
}
var defaultWsOpt = {
    dataMethod: "xml",
    namespaceURL: 'http://mtest.xudc.com:8080/house',
    beforeSend: function () {
        showMsg({
            show: true,
            msg: '正在加载...'
        })
    },
    success: function (data) {
        console.log('defaultWsOpt', data);
        // 关闭消息框
        showMsg({
            show: false
        });
        //console.log(this.callBack)
        var _response = data.Body[this.methodName + 'Response'].result;
        if (_response.code == '0')
            this.callBack && this.callBack(_response.data);
        else
            showMsg({
                show: true,
                msg: _response.msg || '',
                timeOutClose: true
            });
    },
    error: function (err) {
        // 关闭消息框
        showMsg({
            show: false
        });
        // 开启提示消息
        showMsg({
            show: true,
            msg: err || '',
            timeOutClose: true
        });
    }
}
function wsget(opt, callBack) {
    var _options = {callBack: callBack};
    $.extend(_options, defaultWsOpt, opt);
   // console.log(_options);
    soapGetData(_options);
}
var wsUrls = {
    articleservice: 'http://mtest.xudc.com:8080/house/ws/articleservice?wsdl',
    apphousewebservice: 'http://mtest.xudc.com:8080/house/ws/apphousewebservice?wsdl',
    channelservice:'http://mtest.xudc.com:8080//house/ws/channelservice?wsdl'

}
function getArticleDetail(requestData, callBack) {
    var opt = {
        url: wsUrls.articleservice,
        methodName: 'getArticleDetail',
        data: requestData

    }
    wsget(opt, callBack);
}
function getIndexAppList(requestData,callBack){
    var opt = {
        url: wsUrls.apphousewebservice,
        methodName: 'getIndexAppList',
        data: requestData
    }
    wsget(opt, callBack);
}
/**
 * 获取子栏目列表页
 */
function getNextMenu(requestData,callBack){
    var opt = {
        url: wsUrls.channelservice,
        methodName: 'getNextMenu',
        data: requestData
    }
    wsget(opt, callBack);
}
/**
 * 文章列表页
 */
function getArticleList(requestData,callBack){
    var opt = {
        url: wsUrls.articleservice,
        methodName: 'getArticleList',
        data: requestData
    }
    wsget(opt, callBack);
}

